All content is fabricated sample data from DisDown. This website sampler includes all five standalone formats for comparison; it is not the app ZIP bundle layout.
